# Statistics Code Library

A reusable Python library for learning statistics and data science. Functions are organized by formula/topic so you can reuse them with different datasets.

## Quick start

1. Download or clone this repository.
2. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
3. Open a notebook in the repository root or the `practice/` folder.
4. Import functions, for example:
   ```python
   import numpy as np
   from sampling_and_clt.central_limit_theorem import central_limit_theorem
   from distributions.gaussian_distribution import gaussian_probability_between

   data = np.random.randint(1, 1000, 1000)
   sample_means = central_limit_theorem(data, no_of_samples=1000, sample_size=30)

   p = gaussian_probability_between(40000, 80000, mean=60000, sd=10000)
   print(p)
   ```

## Repository map

- `descriptive_statistics/`: mean, median, mode, variance, standard deviation, range, quartiles, IQR, outlier bounds.
- `probability/`: basic, complement, union, conditional probability, independence, Bayes' theorem.
- `distributions/`: Gaussian PDF/CDF/interval probability, z-scores, binomial, Poisson, exponential, uniform.
- `sampling_and_clt/`: random samples, Central Limit Theorem simulations, standard error.
- `correlation_and_regression/`: covariance, correlation, simple linear regression.
- `statistical_inference/`: confidence intervals and common hypothesis tests.
- `visualization/`: reusable plots.
- `practice/`: notebooks for applying the library to specific problems.

## How to use the library

Keep reusable functions in `.py` files. Put changing datasets, parameter values, questions, outputs, graphs, and your own explanations in practice notebooks.

Example:
```python
from distributions.z_scores import calculate_z_score

score = calculate_z_score(x=70000, mean=60000, sd=10000)
print(score)
```

## Notes

- These are educational helpers, not a replacement for checking each problem's assumptions.
- Probability inputs should be between 0 and 1.
- For random simulations, results can vary between runs. Set a random seed in your notebook if you need repeatable results.
- A normal PDF value is a density, not the probability of one exact continuous value.
- Sample and population variance use different denominators; functions make this distinction explicit where relevant.
