"""Covariance and Pearson correlation."""
import numpy as np

def calculate_covariance(x, y, sample=True):
    """Covariance of paired data; sample covariance by default."""
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    if x.size != y.size or x.size < 2:
        raise ValueError("x and y must have equal length of at least two")
    return float(np.cov(x, y, ddof=1 if sample else 0)[0, 1])

def calculate_correlation(x, y):
    """Pearson correlation coefficient."""
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    if x.size != y.size or x.size < 2:
        raise ValueError("x and y must have equal length of at least two")
    if np.std(x) == 0 or np.std(y) == 0:
        raise ValueError("correlation is undefined for constant data")
    return float(np.corrcoef(x, y)[0, 1])
