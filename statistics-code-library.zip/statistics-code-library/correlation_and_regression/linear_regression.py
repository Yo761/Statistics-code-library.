"""Simple least-squares linear regression."""
import numpy as np

def fit_simple_linear_regression(x, y):
    """
    Fit y = slope*x + intercept.
    Returns a dictionary containing slope, intercept, and R-squared.
    """
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    if x.size != y.size or x.size < 2:
        raise ValueError("x and y must have equal length of at least two")
    if np.var(x) == 0:
        raise ValueError("x must contain more than one distinct value")
    slope, intercept = np.polyfit(x, y, 1)
    predictions = slope * x + intercept
    ss_res = np.sum((y - predictions) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r_squared = 1.0 if ss_tot == 0 and ss_res == 0 else (
        float("nan") if ss_tot == 0 else 1 - ss_res / ss_tot
    )
    return {"slope": float(slope), "intercept": float(intercept),
            "r_squared": float(r_squared)}

def predict_linear(x, slope, intercept):
    """Predict y using y = slope*x + intercept."""
    return slope * np.asarray(x) + intercept
