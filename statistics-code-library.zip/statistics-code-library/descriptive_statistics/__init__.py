"""Reusable descriptive-statistics functions."""
