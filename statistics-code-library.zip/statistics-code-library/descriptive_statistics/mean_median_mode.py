"""Mean, median, and mode."""
import numpy as np
from scipy.stats import mode as scipy_mode

def calculate_mean(data):
    """Arithmetic mean of numeric data."""
    data = np.asarray(data)
    if data.size == 0:
        raise ValueError("data must not be empty")
    return float(np.mean(data))

def calculate_median(data):
    """Median of numeric data."""
    data = np.asarray(data)
    if data.size == 0:
        raise ValueError("data must not be empty")
    return float(np.median(data))

def calculate_mode(data):
    """Return one mode. For ties, SciPy returns the smallest modal value."""
    data = np.asarray(data)
    if data.size == 0:
        raise ValueError("data must not be empty")
    result = scipy_mode(data, keepdims=False)
    return result.mode.item() if hasattr(result.mode, "item") else result.mode
