"""Quartiles, interquartile range, and Tukey outlier bounds."""
import numpy as np

def calculate_quartiles(data):
    """Return (Q1, Q2/median, Q3) using NumPy's default percentile method."""
    data = np.asarray(data, dtype=float)
    if data.size == 0:
        raise ValueError("data must not be empty")
    q1, q2, q3 = np.percentile(data, [25, 50, 75])
    return float(q1), float(q2), float(q3)

def calculate_iqr(data):
    """Interquartile range Q3 - Q1."""
    q1, _, q3 = calculate_quartiles(data)
    return float(q3 - q1)

def outlier_bounds(data, multiplier=1.5):
    """Return Tukey lower and upper fences: Q1 - m*IQR, Q3 + m*IQR."""
    if multiplier < 0:
        raise ValueError("multiplier must be non-negative")
    q1, _, q3 = calculate_quartiles(data)
    iqr = q3 - q1
    return float(q1 - multiplier * iqr), float(q3 + multiplier * iqr)
