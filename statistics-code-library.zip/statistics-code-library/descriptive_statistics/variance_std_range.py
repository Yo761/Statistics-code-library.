"""Variance, standard deviation, and range."""
import numpy as np

def calculate_variance(data, sample=False):
    """Variance; population by default, sample variance when sample=True."""
    data = np.asarray(data, dtype=float)
    if data.size == 0:
        raise ValueError("data must not be empty")
    if sample and data.size < 2:
        raise ValueError("sample variance requires at least two observations")
    return float(np.var(data, ddof=1 if sample else 0))

def calculate_std(data, sample=False):
    """Standard deviation; population by default, sample SD when sample=True."""
    data = np.asarray(data, dtype=float)
    if data.size == 0:
        raise ValueError("data must not be empty")
    if sample and data.size < 2:
        raise ValueError("sample standard deviation requires at least two observations")
    return float(np.std(data, ddof=1 if sample else 0))

def calculate_range(data):
    """Maximum minus minimum."""
    data = np.asarray(data)
    if data.size == 0:
        raise ValueError("data must not be empty")
    return float(np.max(data) - np.min(data))
