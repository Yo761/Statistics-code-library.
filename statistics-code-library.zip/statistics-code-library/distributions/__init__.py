"""Reusable probability distribution functions."""
