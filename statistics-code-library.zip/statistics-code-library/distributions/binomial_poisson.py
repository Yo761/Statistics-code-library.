"""Binomial and Poisson probability mass functions and CDFs."""
from scipy.stats import binom, poisson

def binomial_probability(k, n, p):
    """P(X = k) for X ~ Binomial(n, p)."""
    if n < 0 or int(n) != n:
        raise ValueError("n must be a non-negative integer")
    if k < 0 or int(k) != k:
        raise ValueError("k must be a non-negative integer")
    if not 0 <= p <= 1:
        raise ValueError("p must be between 0 and 1")
    return binom.pmf(k, n, p)

def binomial_cdf(k, n, p):
    """P(X <= k) for X ~ Binomial(n, p)."""
    if n < 0 or int(n) != n:
        raise ValueError("n must be a non-negative integer")
    if not 0 <= p <= 1:
        raise ValueError("p must be between 0 and 1")
    return binom.cdf(k, n, p)

def poisson_probability(k, rate):
    """P(X = k) for X ~ Poisson(rate)."""
    if k < 0 or int(k) != k:
        raise ValueError("k must be a non-negative integer")
    if rate < 0:
        raise ValueError("rate must be non-negative")
    return poisson.pmf(k, mu=rate)

def poisson_cdf(k, rate):
    """P(X <= k) for X ~ Poisson(rate)."""
    if rate < 0:
        raise ValueError("rate must be non-negative")
    return poisson.cdf(k, mu=rate)
