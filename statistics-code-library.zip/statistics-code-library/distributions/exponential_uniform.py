"""Exponential and continuous uniform distribution functions."""
from scipy.stats import expon, uniform

def exponential_pdf(x, rate):
    """Exponential PDF with rate lambda; scale is 1/lambda."""
    if rate <= 0:
        raise ValueError("rate must be positive")
    if x < 0:
        return 0.0
    return expon.pdf(x, scale=1 / rate)

def exponential_cdf(x, rate):
    """P(X <= x) for an exponential distribution."""
    if rate <= 0:
        raise ValueError("rate must be positive")
    if x < 0:
        return 0.0
    return expon.cdf(x, scale=1 / rate)

def uniform_pdf(x, a, b):
    """PDF for continuous Uniform(a, b)."""
    if a >= b:
        raise ValueError("a must be less than b")
    return uniform.pdf(x, loc=a, scale=b - a)

def uniform_probability_between(low, high, a, b):
    """P(low <= X <= high) for X ~ Uniform(a, b)."""
    if a >= b:
        raise ValueError("a must be less than b")
    if low > high:
        raise ValueError("low must be <= high")
    return max(0.0, uniform.cdf(high, loc=a, scale=b-a) -
               uniform.cdf(low, loc=a, scale=b-a))
