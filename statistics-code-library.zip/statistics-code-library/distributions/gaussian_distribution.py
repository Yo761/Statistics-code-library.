"""Normal (Gaussian) distribution functions."""
from scipy.stats import norm

def gaussian_pdf(x, mean, sd):
    """Normal probability density at x (density, not point probability)."""
    if sd <= 0:
        raise ValueError("sd must be positive")
    return norm.pdf(x, loc=mean, scale=sd)

def gaussian_cdf(x, mean, sd):
    """P(X <= x) for a normal distribution."""
    if sd <= 0:
        raise ValueError("sd must be positive")
    return norm.cdf(x, loc=mean, scale=sd)

def gaussian_probability_between(a, b, mean, sd):
    """P(a <= X <= b) = CDF(b) - CDF(a)."""
    if sd <= 0:
        raise ValueError("sd must be positive")
    if a > b:
        raise ValueError("a must be <= b")
    return norm.cdf(b, loc=mean, scale=sd) - norm.cdf(a, loc=mean, scale=sd)

def gaussian_quantile(probability, mean, sd):
    """Return x such that P(X <= x) equals probability."""
    if not 0 < probability < 1:
        raise ValueError("probability must be strictly between 0 and 1")
    if sd <= 0:
        raise ValueError("sd must be positive")
    return norm.ppf(probability, loc=mean, scale=sd)
