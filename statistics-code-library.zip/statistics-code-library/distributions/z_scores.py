"""Z-score and standardization helpers."""

def calculate_z_score(x, mean, sd):
    """z = (x - mean) / sd."""
    if sd <= 0:
        raise ValueError("sd must be positive")
    return (x - mean) / sd

def standardize_data(data):
    """Return standardized values using the data's population mean and SD."""
    import numpy as np
    data = np.asarray(data, dtype=float)
    if data.size == 0:
        raise ValueError("data must not be empty")
    sd = np.std(data, ddof=0)
    if sd == 0:
        raise ValueError("cannot standardize data with zero standard deviation")
    return (data - np.mean(data)) / sd
