"""Reusable probability functions."""
