"""Basic, complement, union, and intersection probability helpers."""

def _check_probability(p, name="probability"):
    if not 0 <= p <= 1:
        raise ValueError(f"{name} must be between 0 and 1")

def basic_probability(favorable, total):
    """P(A) = favorable outcomes / total equally likely outcomes."""
    if total <= 0:
        raise ValueError("total must be positive")
    if favorable < 0 or favorable > total:
        raise ValueError("favorable must be between 0 and total")
    return favorable / total

def complement_probability(p_a):
    """P(not A) = 1 - P(A)."""
    _check_probability(p_a, "p_a")
    return 1 - p_a

def probability_union(p_a, p_b, p_a_and_b):
    """P(A or B) = P(A) + P(B) - P(A and B)."""
    for p, name in [(p_a, "p_a"), (p_b, "p_b"), (p_a_and_b, "p_a_and_b")]:
        _check_probability(p, name)
    result = p_a + p_b - p_a_and_b
    if result < -1e-12 or result > 1 + 1e-12:
        raise ValueError("inputs are inconsistent with a valid union probability")
    return min(1.0, max(0.0, result))
