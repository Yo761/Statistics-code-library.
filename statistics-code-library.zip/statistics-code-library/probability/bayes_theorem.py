"""Bayes' theorem."""

def bayes_theorem(p_b_given_a, p_a, p_b):
    """P(A | B) = P(B | A) * P(A) / P(B)."""
    for p, name in [(p_b_given_a, "p_b_given_a"), (p_a, "p_a"), (p_b, "p_b")]:
        if not 0 <= p <= 1:
            raise ValueError(f"{name} must be between 0 and 1")
    if p_b == 0:
        raise ValueError("p_b must be greater than zero")
    result = p_b_given_a * p_a / p_b
    if result > 1 + 1e-9:
        raise ValueError("inputs are inconsistent with Bayes' theorem")
    return min(1.0, result)
