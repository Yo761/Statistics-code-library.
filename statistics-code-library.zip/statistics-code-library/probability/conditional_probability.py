"""Conditional probability and independence."""

def conditional_probability(p_a_and_b, p_b):
    """P(A | B) = P(A and B) / P(B), requiring P(B) > 0."""
    if not 0 <= p_a_and_b <= 1 or not 0 <= p_b <= 1:
        raise ValueError("probabilities must be between 0 and 1")
    if p_b == 0:
        raise ValueError("p_b must be greater than zero")
    if p_a_and_b > p_b:
        raise ValueError("P(A and B) cannot exceed P(B)")
    return p_a_and_b / p_b

def are_independent(p_a, p_b, p_a_and_b, tolerance=1e-9):
    """Return True when P(A and B) is approximately P(A)*P(B)."""
    for p in (p_a, p_b, p_a_and_b):
        if not 0 <= p <= 1:
            raise ValueError("probabilities must be between 0 and 1")
    return abs(p_a_and_b - p_a * p_b) <= tolerance
