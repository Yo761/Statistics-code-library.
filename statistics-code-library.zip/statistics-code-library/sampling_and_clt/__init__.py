"""Sampling and Central Limit Theorem helpers."""
