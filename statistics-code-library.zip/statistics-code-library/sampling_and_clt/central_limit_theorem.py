"""Central Limit Theorem simulation: generate repeated sample means."""
import numpy as np

def central_limit_theorem(data, no_of_samples, sample_size, random_state=None):
    """
    Draw repeated samples with replacement and return their means.

    data: source population/observed values
    no_of_samples: number of repeated samples
    sample_size: size of each sample
    random_state: optional seed for reproducible results
    """
    data = np.asarray(data)
    if data.size == 0:
        raise ValueError("data must not be empty")
    if no_of_samples < 1 or int(no_of_samples) != no_of_samples:
        raise ValueError("no_of_samples must be a positive integer")
    if sample_size < 1 or int(sample_size) != sample_size:
        raise ValueError("sample_size must be a positive integer")
    rng = np.random.default_rng(random_state)
    sample_means = np.empty(int(no_of_samples), dtype=float)
    for i in range(int(no_of_samples)):
        sample = rng.choice(data, size=int(sample_size), replace=True)
        sample_means[i] = np.mean(sample)
    return sample_means
