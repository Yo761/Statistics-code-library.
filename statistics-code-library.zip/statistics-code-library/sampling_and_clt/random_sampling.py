"""Random sampling helpers."""
import numpy as np

def draw_sample(data, sample_size, replace=True, random_state=None):
    """Draw a sample from data, with or without replacement."""
    data = np.asarray(data)
    if data.size == 0:
        raise ValueError("data must not be empty")
    if sample_size < 1 or int(sample_size) != sample_size:
        raise ValueError("sample_size must be a positive integer")
    if not replace and sample_size > data.size:
        raise ValueError("sample_size cannot exceed data size without replacement")
    rng = np.random.default_rng(random_state)
    return rng.choice(data, size=sample_size, replace=replace)
