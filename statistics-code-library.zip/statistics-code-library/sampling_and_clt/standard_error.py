"""Standard error helpers."""
import numpy as np

def standard_error_mean(data):
    """Estimated standard error of the sample mean: sample SD / sqrt(n)."""
    data = np.asarray(data, dtype=float)
    if data.size < 2:
        raise ValueError("at least two observations are required")
    return float(np.std(data, ddof=1) / np.sqrt(data.size))

def theoretical_standard_error(population_sd, sample_size):
    """Theoretical SE of the mean: population SD / sqrt(sample size)."""
    if population_sd < 0:
        raise ValueError("population_sd must be non-negative")
    if sample_size <= 0:
        raise ValueError("sample_size must be positive")
    return population_sd / np.sqrt(sample_size)
