"""Confidence intervals for a mean."""
import numpy as np
from scipy.stats import t

def mean_confidence_interval(data, confidence=0.95):
    """
    Two-sided t confidence interval for a population mean.
    Assumes independent observations and a suitable population/sample distribution.
    """
    data = np.asarray(data, dtype=float)
    n = data.size
    if n < 2:
        raise ValueError("at least two observations are required")
    if not 0 < confidence < 1:
        raise ValueError("confidence must be between 0 and 1")
    mean = np.mean(data)
    se = np.std(data, ddof=1) / np.sqrt(n)
    critical = t.ppf((1 + confidence) / 2, df=n - 1)
    return float(mean - critical * se), float(mean + critical * se)
