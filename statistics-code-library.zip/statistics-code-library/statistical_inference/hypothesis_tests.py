"""Common t-tests."""
from scipy.stats import ttest_1samp, ttest_ind, ttest_rel

def one_sample_t_test(data, hypothesized_mean):
    """Two-sided one-sample t-test."""
    return ttest_1samp(data, popmean=hypothesized_mean)

def independent_two_sample_t_test(group_a, group_b, equal_var=False):
    """Two-sided independent-samples t-test; Welch's test by default."""
    return ttest_ind(group_a, group_b, equal_var=equal_var)

def paired_t_test(before, after):
    """Two-sided paired t-test for matched observations."""
    if len(before) != len(after):
        raise ValueError("before and after must have the same length")
    return ttest_rel(before, after)
