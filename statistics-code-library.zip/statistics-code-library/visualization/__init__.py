"""Reusable plotting functions."""
