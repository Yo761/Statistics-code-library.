"""Reusable plots for distributions and sampling results."""
import matplotlib.pyplot as plt

def plot_histogram(data, bins=30, title="Distribution", xlabel="Value"):
    """Plot a histogram of numeric data."""
    plt.figure()
    plt.hist(data, bins=bins, density=True, edgecolor="black")
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel("Density")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

def plot_sampling_distribution(sample_means, bins=30):
    """Plot a histogram of simulated sample means."""
    plot_histogram(
        sample_means, bins=bins,
        title="Sampling Distribution of Sample Means",
        xlabel="Sample mean"
    )
